var locations_neutrogpon = [
/* CIDADES ADICIONADAS MANUALMENTE, POR ERRO NO CADASTRO DE CONSULTA API DA CLARO */

/* CIDADES CONSULTADAS AUTOMATICAMENTE PELO SCRIPT */
{ name: 'Guaratuba, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-25.881672', longitude: '-48.575223' },
{ name: 'Ibiporã, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-23.265941', longitude: '-51.052243' },
{ name: 'Paiçandu, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-23.455534', longitude: '-52.046013' },
{ name: 'Piraquara, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-25.442171', longitude: '-49.062411' },
{ name: 'Quatro Barras, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-25.367317', longitude: '-49.076306' },
{ name: 'Telêmaco Borba, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-24.32452', longitude: '-50.617585' },
{ name: 'União da Vitória, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-26.227319', longitude: '-51.087313' }
];
