var locations_neutrogpon = [
/* CIDADES ADICIONADAS MANUALMENTE, POR ERRO NO CADASTRO DE CONSULTA API DA CLARO */
{ name: 'João Monlevade, MG <br> GPON REDE NEUTRA', color: 'grey', latitude: '-19.812646', longitude: '-43.173463' },
{ name: 'Palmas, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-26.483868', longitude: '-51.988812' },
{ name: 'Piraquara, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-25.442171', longitude: '-49.062411' },

/* CIDADES CONSULTADAS AUTOMATICAMENTE PELO SCRIPT */
{ name: 'Foz do Iguaçu, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-25.542748', longitude: '-54.582689' },
{ name: 'Guaratuba, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-25.881672', longitude: '-48.575223' },
{ name: 'Ibiporã, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-23.265941', longitude: '-51.052243' },
{ name: 'Marechal Cândido Rondon, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-24.557891', longitude: '-54.056115' },
{ name: 'Paiçandu, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-23.455534', longitude: '-52.046013' },
{ name: 'Quatro Barras, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-25.367317', longitude: '-49.076306' },
{ name: 'Telêmaco Borba, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-24.32452', longitude: '-50.617585' },
{ name: 'União da Vitória, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-26.227319', longitude: '-51.087313' }
];
