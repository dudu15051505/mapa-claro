var locations_neutrohfc = [
/* CIDADES ADICIONADAS MANUALMENTE, POR ERRO NO CADASTRO DE CONSULTA API DA CLARO */
{ name: 'João Monlevade, MG <br> HFC REDE NEUTRA', color: 'violet', latitude: '-19.812646', longitude: '-43.173463' },
{ name: 'Piraquara, PR <br> HFC REDE NEUTRA', color: 'violet', latitude: '-25.442171', longitude: '-49.062411' },

/* CIDADES CONSULTADAS AUTOMATICAMENTE PELO SCRIPT */
{ name: 'Paiçandu, PR <br> HFC REDE NEUTRA', color: 'violet', latitude: '-23.455534', longitude: '-52.046013' },
{ name: 'Quatro Barras, PR <br> HFC REDE NEUTRA', color: 'violet', latitude: '-25.367317', longitude: '-49.076306' }
];
