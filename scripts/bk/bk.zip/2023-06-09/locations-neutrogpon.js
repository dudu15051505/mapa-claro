var locations_neutrogpon = [
/* CIDADES ADICIONADAS MANUALMENTE, POR ERRO NO CADASTRO DE CONSULTA API DA CLARO */
{ name: 'João Monlevade, MG <br> GPON REDE NEUTRA', color: 'grey', latitude: '-19.812646', longitude: '-43.173463' },
{ name: 'Piraquara, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-25.442171', longitude: '-49.062411' },

/* CIDADES CONSULTADAS AUTOMATICAMENTE PELO SCRIPT */
{ name: 'Paiçandu, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-23.455534', longitude: '-52.046013' },
{ name: 'Quatro Barras, PR <br> GPON REDE NEUTRA', color: 'grey', latitude: '-25.367317', longitude: '-49.076306' }
];
